import os from 'os';

export interface SystemInfo {
  platform: string;
  arch: string;
  cpus: number;
  totalMemory: string;
  freeMemory: string;
  uptime: string;
  hostname: string;
}

export function getSystemInfo(detailed = false): SystemInfo {
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  return {
    platform: os.platform(),
    arch: os.arch(),
    cpus: os.cpus().length,
    totalMemory: `${Math.round(totalMem / 1024 / 1024 / 1024)} GB`,
    freeMemory: `${Math.round(freeMem / 1024 / 1024 / 1024)} GB`,
    uptime: `${Math.round(os.uptime() / 3600)} 小时`,
    hostname: os.hostname()
  };
}
