import { getSystemInfo } from './tools/system-info.js';

export function register(api: any) {
  const config = api.getConfig();
  const showDetails = config?.showDetails || false;

  api.registerTool({
    name: 'get_system_info',
    description: '获取当前系统的信息',
    parameters: {
      type: 'object',
      properties: {
        detailed: { type: 'boolean', description: '是否显示详细信息', default: false }
      },
      additionalProperties: false
    },
    async execute(toolCallId: string, params: any) {
      const { detailed = showDetails } = params;
      const info = getSystemInfo(detailed);
      return {
        content: `系统信息：平台=${info.platform}, 架构=${info.arch}, CPU=${info.cpus}核`,
        isError: false
      };
    }
  });

  api.getLogger().info('System Info Plugin 已成功注册！');
}
